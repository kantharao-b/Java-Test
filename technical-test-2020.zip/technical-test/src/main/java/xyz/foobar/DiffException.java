package xyz.foobar;

/**
 * Implement or modify this class as you see fit
 *
 */
public class DiffException extends Exception {

	private static final long serialVersionUID = -7698912729249813850L;

}
